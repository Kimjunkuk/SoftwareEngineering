import pyautogui
import time

# while True:
#     print("Current Mouse Position: ",pyautogui.position())
#     time.sleep(1)

from datetime import datetime

s=datetime.now().strftime('%H:%M:%S')
print(s)